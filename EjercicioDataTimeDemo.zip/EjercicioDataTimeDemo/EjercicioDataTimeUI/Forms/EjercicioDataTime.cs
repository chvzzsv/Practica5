﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EjercicioDataTimeUI.Forms
{
    public partial class EjercicioDataTime : Form
    {
        public EjercicioDataTime()
        {
            InitializeComponent();
        }
        void validarFecha()
        {
            DateTime hoy = DateTime.Today;
            if (dateTimePicker1.Value.Date > hoy)
            {
                MessageBox.Show("Fecha inválida ", "Error de ingreso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                label2.Text = ("No puedes seleccionar futura");
            }
            else if (dateTimePicker1.Value.AddYears(18) <= hoy)
            {
                MessageBox.Show("Eres mayor de edad ", "Confirmación", MessageBoxButtons.OK, MessageBoxIcon.Information);
                label2.Text = ("Eres mayor de edad");
            }
            else
            {
                MessageBox.Show("Eres menor de eddad ", "Confirmación", MessageBoxButtons.OK, MessageBoxIcon.Information);
                label2.Text = ("Eres menor de edad");
            }
        }

        private void calcularBtn_Click(object sender, EventArgs e)
        {
            validarFecha();
        }
    }
}
