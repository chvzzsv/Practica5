﻿namespace EjercicioDataTimeUI.Forms
{
    partial class EjercicioDataTime
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label2 = new Label();
            dateTimePicker1 = new DateTimePicker();
            calcularBtn = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(306, 280);
            label2.Name = "label2";
            label2.Size = new Size(190, 28);
            label2.TabIndex = 8;
            label2.Text = "Validación de edad";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(266, 158);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(269, 27);
            dateTimePicker1.TabIndex = 7;
            // 
            // calcularBtn
            // 
            calcularBtn.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            calcularBtn.Location = new Point(356, 219);
            calcularBtn.Name = "calcularBtn";
            calcularBtn.Size = new Size(94, 29);
            calcularBtn.TabIndex = 6;
            calcularBtn.Text = "Calcular";
            calcularBtn.UseVisualStyleBackColor = true;
            calcularBtn.Click += calcularBtn_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(306, 107);
            label1.Name = "label1";
            label1.Size = new Size(205, 28);
            label1.TabIndex = 5;
            label1.Text = "Verificación de edad";
            // 
            // EjercicioDataTime
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Lime;
            ClientSize = new Size(816, 441);
            Controls.Add(label2);
            Controls.Add(dateTimePicker1);
            Controls.Add(calcularBtn);
            Controls.Add(label1);
            Name = "EjercicioDataTime";
            Text = "EjercicioDataTime";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label2;
        private DateTimePicker dateTimePicker1;
        private Button calcularBtn;
        private Label label1;
    }
}